package com.example.myapplication;



import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ListView lvCities, lvPlates;
    private TextView tvResult;

    private String selectedCity = null;
    private String selectedPlate = null;

    private Map<String, String> cityPlateMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvCities = findViewById(R.id.lvCities);
        lvPlates = findViewById(R.id.lvPlates);
        tvResult = findViewById(R.id.tvResult);

        // 1. Verileri Hazırla
        cityPlateMap = new HashMap<>();
        cityPlateMap.put("Adana", "01");
        cityPlateMap.put("Ankara", "06");
        cityPlateMap.put("İstanbul", "34");
        cityPlateMap.put("İzmir", "35");
        cityPlateMap.put("Bursa", "16");
        cityPlateMap.put("Antalya", "07");

        List<String> cities = new ArrayList<>(cityPlateMap.keySet());
        List<String> plates = new ArrayList<>(cityPlateMap.values());

        // Listeleri karıştır (aynı hizada olmasınlar ki oyun olsun)
        Collections.shuffle(cities);
        Collections.shuffle(plates);

        // 2. Adaptörleri Bağla
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, cities);
        ArrayAdapter<String> plateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, plates);

        lvCities.setAdapter(cityAdapter);
        lvPlates.setAdapter(plateAdapter);

        // Liste elemanlarının seçilebilir olduğunu belirtiyoruz
        lvCities.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lvPlates.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // 3. Tıklama Dinleyicileri (Listeners)
        lvCities.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedCity = cities.get(position);
                checkMatch();
            }
        });

        lvPlates.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPlate = plates.get(position);
                checkMatch();
            }
        });
    }

    // 4. Eşleşme Kontrol Metodu
    private void checkMatch() {
        // Her iki listeden de seçim yapıldıysa kontrol et
        if (selectedCity != null && selectedPlate != null) {

            String correctPlate = cityPlateMap.get(selectedCity);

            if (correctPlate != null && correctPlate.equals(selectedPlate)) {
                tvResult.setText("Doğru Eşleşme: " + selectedCity + " - " + selectedPlate);
                tvResult.setTextColor(Color.parseColor("#4CAF50")); // Yeşil renk
                Toast.makeText(this, "Tebrikler!", Toast.LENGTH_SHORT).show();
            } else {
                tvResult.setText("Hatalı Eşleşme: " + selectedCity + " - " + selectedPlate);
                tvResult.setTextColor(Color.parseColor("#F44336")); // Kırmızı renk
                Toast.makeText(this, "Yanlış, tekrar dene.", Toast.LENGTH_SHORT).show();
            }

            // Seçimleri sıfırla (Kullanıcı yeni bir ikili seçebilsin diye)
            lvCities.clearChoices();
            lvPlates.clearChoices();
            lvCities.requestLayout();
            lvPlates.requestLayout();

            selectedCity = null;
            selectedPlate = null;
        }
    }
}